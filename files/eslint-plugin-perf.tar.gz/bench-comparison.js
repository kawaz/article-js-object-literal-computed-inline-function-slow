// 修正前後のパフォーマンス比較

const N = 100000;

function bench(name, fn) {
  for (let i = 0; i < 1000; i++) fn();
  const start = performance.now();
  for (let i = 0; i < N; i++) {
    const obj = fn();
    obj[Symbol.dispose]();
  }
  return performance.now() - start;
}

// ========================================
// Before (遅い)
// ========================================
function createBefore() {
  return { [Symbol.dispose]() { } };
}

// ========================================
// After (ESLint --fix 後)
// ========================================
function createAfter() {
  const obj = {}; obj[Symbol.dispose] = function() { };
  return obj;
}

// ========================================
// 比較
// ========================================
console.log("=== Performance Comparison ===\n");

const before = bench("Before (literal + computed + method)", createBefore);
const after = bench("After (property assignment)", createAfter);

console.log(`Before: ${before.toFixed(2)}ms`);
console.log(`After:  ${after.toFixed(2)}ms`);
console.log(`Speedup: ${(before / after).toFixed(1)}x faster`);
