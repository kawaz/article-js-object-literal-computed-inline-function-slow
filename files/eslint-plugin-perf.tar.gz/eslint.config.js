const perfPlugin = require("./index.js");

module.exports = [
  {
    plugins: {
      perf: perfPlugin,
    },
    rules: {
      "perf/no-computed-property-method": "warn",
    },
  },
];
