// テスト対象コード

// Case 1: 単純な computed method - 修正対象
const obj1 = { [Symbol.dispose]() { console.log("disposed"); } };

// Case 2: computed + arrow - 修正対象  
const obj2 = { [Symbol.dispose]: () => console.log("disposed") };

// Case 3: 静的プロパティと混在 - 修正対象
const obj3 = {
  name: "test",
  getValue() { return 42; },
  [Symbol.dispose]() { console.log("cleanup"); }
};

// Case 4: OK - 静的キーのみ
const obj4 = { dispose() {} };

// Case 5: OK - 後付けパターン
const obj5 = {};
obj5[Symbol.dispose] = function() {};

// Case 6: OK - class
class MyClass {
  [Symbol.dispose]() {}
}
