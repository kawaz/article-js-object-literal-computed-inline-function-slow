// ベンチマーク用ユーティリティ
function bench(name, fn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) fn();
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) fn();
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
  return end - start;
}

function benchAccess(name, createFn, iterations = 100000) {
  // オブジェクトを大量生成
  const objects = [];
  for (let i = 0; i < iterations; i++) {
    objects.push(createFn());
  }
  
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    objects[i % objects.length][Symbol.dispose]?.();
  }
  
  // 参照のベンチマーク
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    objects[i][Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name} (access): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

console.log("=== 生成コスト比較 ===\n");

console.log("--- 静的キーのみ ---");
bench("static + function", () => ({ release: function() {} }));
bench("static + arrow", () => ({ release: () => {} }));
bench("static + method", () => ({ release() {} }));

console.log("\n--- computed Symbol + 値 ---");
bench("computed + value", () => ({ [Symbol.dispose]: 1 }));

console.log("\n--- computed Symbol + function ---");
bench("computed + function", () => ({ [Symbol.dispose]: function() {} }));
bench("computed + arrow", () => ({ [Symbol.dispose]: () => {} }));
bench("computed + method", () => ({ [Symbol.dispose]() {} }));

console.log("\n--- 後付けパターン ---");
bench("addLater + function", () => {
  const obj = {};
  obj[Symbol.dispose] = function() {};
  return obj;
});
bench("addLater + arrow", () => {
  const obj = {};
  obj[Symbol.dispose] = () => {};
  return obj;
});

console.log("\n--- class ---");
class WithMethod {
  [Symbol.dispose]() {}
}
class WithArrow {
  dispose = () => {};  // arrow as instance field
}
bench("class + method", () => new WithMethod());
bench("class + arrow field", () => new WithArrow());

console.log("\n\n=== 参照コスト比較 ===\n");

console.log("--- 同一Shape (class) ---");
benchAccess("class method", () => new WithMethod());

console.log("\n--- リテラル computed Symbol ---");
benchAccess("literal computed + function", () => ({ [Symbol.dispose]: function() {} }));
benchAccess("literal computed + arrow", () => ({ [Symbol.dispose]: () => {} }));
benchAccess("literal computed + method", () => ({ [Symbol.dispose]() {} }));

console.log("\n--- 後付けパターン ---");
benchAccess("addLater + function", () => {
  const obj = {};
  obj[Symbol.dispose] = function() {};
  return obj;
});
benchAccess("addLater + arrow", () => {
  const obj = {};
  obj[Symbol.dispose] = () => {};
  return obj;
});

console.log("\n\n=== IC状態の検証 ===\n");

// 同一Shapeのオブジェクトを大量に作って参照
function testMonomorphic() {
  const objects = [];
  for (let i = 0; i < 100000; i++) {
    objects.push(new WithMethod());
  }
  
  const start = performance.now();
  for (let i = 0; i < 100000; i++) {
    objects[i][Symbol.dispose]();
  }
  return performance.now() - start;
}

// 毎回新しいShapeになりうるオブジェクトを参照
function testMegamorphic() {
  const objects = [];
  for (let i = 0; i < 100000; i++) {
    objects.push({ [Symbol.dispose]() {} });
  }
  
  const start = performance.now();
  for (let i = 0; i < 100000; i++) {
    objects[i][Symbol.dispose]();
  }
  return performance.now() - start;
}

console.log(`Monomorphic (class): ${testMonomorphic().toFixed(2)}ms`);
console.log(`Potentially Megamorphic (literal computed): ${testMegamorphic().toFixed(2)}ms`);

console.log("\n\n=== 追加検証: 本当に毎回別Shapeか？ ===\n");

// V8の %HaveSameMap() は使えないので、プロパティの順序で間接的に確認
const obj1 = { [Symbol.dispose]() {} };
const obj2 = { [Symbol.dispose]() {} };
const obj3 = new WithMethod();
const obj4 = new WithMethod();

console.log("obj1 keys:", Object.getOwnPropertySymbols(obj1));
console.log("obj2 keys:", Object.getOwnPropertySymbols(obj2));
console.log("obj1[Symbol.dispose] === obj2[Symbol.dispose]:", obj1[Symbol.dispose] === obj2[Symbol.dispose]);
console.log("obj3[Symbol.dispose] === obj4[Symbol.dispose]:", obj3[Symbol.dispose] === obj4[Symbol.dispose]);
