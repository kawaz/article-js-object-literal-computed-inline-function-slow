// 135ms の謎を追求するベンチマーク

console.log("=== 135ms の謎を追求 ===\n");

// 元のコードに近い形で再現
function createLockLiteral() {
  let released = false;
  return {
    release() {
      if (released) return;
      released = true;
    },
    [Symbol.dispose]() {
      this.release();
    }
  };
}

function createLockAddLater() {
  let released = false;
  const obj = {
    release() {
      if (released) return;
      released = true;
    }
  };
  obj[Symbol.dispose] = function() {
    this.release();
  };
  return obj;
}

class LockClass {
  released = false;
  release() {
    if (this.released) return;
    this.released = true;
  }
  [Symbol.dispose]() {
    this.release();
  }
}

// テスト1: using 文での利用（生成+即dispose）
console.log("--- using 文シミュレーション (生成→即dispose) ---");

function benchUsing(name, createFn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

benchUsing("literal computed", createLockLiteral);
benchUsing("addLater", createLockAddLater);
benchUsing("class", () => new LockClass());

// テスト2: 混在した Shape での IC 汚染
console.log("\n--- IC汚染テスト (異なるShape混在) ---");

function benchMixedShapes() {
  // 異なる Shape のオブジェクトを混ぜて作成
  const objects = [];
  for (let i = 0; i < 10000; i++) {
    // 毎回微妙に違う構造
    if (i % 4 === 0) {
      objects.push({ [Symbol.dispose]() {}, a: 1 });
    } else if (i % 4 === 1) {
      objects.push({ [Symbol.dispose]() {}, b: 2 });
    } else if (i % 4 === 2) {
      objects.push({ [Symbol.dispose]() {}, c: 3 });
    } else {
      objects.push({ [Symbol.dispose]() {} });
    }
  }
  
  const start = performance.now();
  for (let j = 0; j < 100; j++) {
    for (let i = 0; i < objects.length; i++) {
      objects[i][Symbol.dispose]();
    }
  }
  const end = performance.now();
  console.log(`Mixed shapes (4 variants, 1M access): ${(end - start).toFixed(2)}ms`);
}

benchMixedShapes();

// テスト3: 同一関数内で大量呼び出し
console.log("\n--- 同一関数内での大量呼び出し ---");

function hotLoop(createFn, iterations) {
  let sum = 0;
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
    sum++;
  }
  return sum;
}

function benchHotLoop(name, createFn) {
  // ウォームアップ
  hotLoop(createFn, 1000);
  
  const start = performance.now();
  hotLoop(createFn, 100000);
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

benchHotLoop("literal computed", createLockLiteral);
benchHotLoop("addLater", createLockAddLater);
benchHotLoop("class", () => new LockClass());

// テスト4: プロファイラを意識した計測（関数分離）
console.log("\n--- 関数分離での計測 (dispose呼び出しのみ) ---");

function measureDisposeOnly(objects) {
  const start = performance.now();
  for (let i = 0; i < objects.length; i++) {
    objects[i][Symbol.dispose]();  // ← この行だけ計測したい
  }
  return performance.now() - start;
}

const literalObjects = Array.from({ length: 100000 }, () => createLockLiteral());
const addLaterObjects = Array.from({ length: 100000 }, () => createLockAddLater());
const classObjects = Array.from({ length: 100000 }, () => new LockClass());

// リセット（released = false に戻す）
literalObjects.forEach(o => { /* released はクロージャ内なのでリセット不可 */ });

console.log(`literal computed (dispose only): ${measureDisposeOnly(literalObjects).toFixed(2)}ms`);
console.log(`addLater (dispose only): ${measureDisposeOnly(addLaterObjects).toFixed(2)}ms`);
console.log(`class (dispose only): ${measureDisposeOnly(classObjects).toFixed(2)}ms`);

// テスト5: this参照のコスト
console.log("\n--- this参照のコスト検証 ---");

function createWithThis() {
  return {
    value: 42,
    [Symbol.dispose]() {
      return this.value;  // thisを参照
    }
  };
}

function createWithoutThis() {
  const value = 42;
  return {
    [Symbol.dispose]() {
      return value;  // クロージャで参照
    }
  };
}

function benchThis(name, createFn) {
  const objects = Array.from({ length: 100000 }, createFn);
  
  const start = performance.now();
  for (let i = 0; i < objects.length; i++) {
    objects[i][Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

benchThis("with this.value", createWithThis);
benchThis("with closure", createWithoutThis);

// テスト6: 本当に別Shapeになってるか確認（V8 trace用）
console.log("\n--- Shape一致確認 ---");
const lit1 = createLockLiteral();
const lit2 = createLockLiteral();
const add1 = createLockAddLater();
const add2 = createLockAddLater();
const cls1 = new LockClass();
const cls2 = new LockClass();

console.log("literal: dispose same?", lit1[Symbol.dispose] === lit2[Symbol.dispose]);
console.log("addLater: dispose same?", add1[Symbol.dispose] === add2[Symbol.dispose]);
console.log("class: dispose same?", cls1[Symbol.dispose] === cls2[Symbol.dispose]);

// テスト7: Deoptimization の検出
console.log("\n--- 長時間実行での劣化テスト ---");

function runLong(name, createFn) {
  const times = [];
  for (let batch = 0; batch < 10; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    times.push(performance.now() - start);
  }
  console.log(`${name}: ${times.map(t => t.toFixed(1)).join(', ')}ms`);
}

runLong("literal computed", createLockLiteral);
runLong("class", () => new LockClass());
