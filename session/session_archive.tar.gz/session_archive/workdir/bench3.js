// JIT最適化とDeoptimizationの検証

console.log("=== JIT最適化の挙動検証 ===\n");

function createLockLiteral() {
  let released = false;
  return {
    release() {
      if (released) return;
      released = true;
    },
    [Symbol.dispose]() {
      this.release();
    }
  };
}

class LockClass {
  released = false;
  release() {
    if (this.released) return;
    this.released = true;
  }
  [Symbol.dispose]() {
    this.release();
  }
}

// 細かい粒度で時間経過を追跡
console.log("--- 細粒度の時間追跡 (1万回ごと) ---");

function trackProgress(name, createFn, total = 100000, chunk = 10000) {
  const times = [];
  for (let i = 0; i < total; i += chunk) {
    const start = performance.now();
    for (let j = 0; j < chunk; j++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    times.push(performance.now() - start);
  }
  console.log(`${name}:`);
  times.forEach((t, i) => {
    console.log(`  ${(i * chunk / 1000)}k-${((i + 1) * chunk / 1000)}k: ${t.toFixed(2)}ms`);
  });
  console.log(`  Total: ${times.reduce((a, b) => a + b, 0).toFixed(2)}ms`);
}

trackProgress("literal computed", createLockLiteral);
console.log();
trackProgress("class", () => new LockClass());

// 最初の1回目が特に遅いか？
console.log("\n--- 最初の数回の計測 ---");

function measureFirst(name, createFn) {
  const times = [];
  for (let i = 0; i < 10; i++) {
    const start = performance.now();
    for (let j = 0; j < 1000; j++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    times.push(performance.now() - start);
  }
  console.log(`${name}: ${times.map(t => t.toFixed(2)).join(', ')}ms`);
}

// 新しいセッションをシミュレート（eval で新しい関数を作成）
console.log("Fresh functions:");
const freshLiteral = eval(`(function() {
  let released = false;
  return {
    release() { if (released) return; released = true; },
    [Symbol.dispose]() { this.release(); }
  };
})`);
measureFirst("fresh literal", freshLiteral);

const FreshClass = eval(`(class {
  released = false;
  release() { if (this.released) return; this.released = true; }
  [Symbol.dispose]() { this.release(); }
})`);
measureFirst("fresh class", () => new FreshClass());

// 呼び出しサイトの影響
console.log("\n--- 呼び出しサイトの影響 ---");

function callSiteTest() {
  // 同じ呼び出しサイトで異なるShapeのオブジェクトを呼び出す
  const objects = [];
  
  // 前半: literal
  for (let i = 0; i < 50000; i++) {
    objects.push(createLockLiteral());
  }
  // 後半: class
  for (let i = 0; i < 50000; i++) {
    objects.push(new LockClass());
  }
  
  // 全部同じ呼び出しサイトでdispose
  const start = performance.now();
  for (let i = 0; i < objects.length; i++) {
    objects[i][Symbol.dispose]();  // ← この1行で全て処理
  }
  const end = performance.now();
  console.log(`Mixed call site (literal + class): ${(end - start).toFixed(2)}ms`);
  
  // 別々に計測
  const literalOnly = objects.slice(0, 50000);
  const classOnly = objects.slice(50000);
  
  const start2 = performance.now();
  for (let i = 0; i < literalOnly.length; i++) {
    literalOnly[i][Symbol.dispose]();
  }
  const mid = performance.now();
  for (let i = 0; i < classOnly.length; i++) {
    classOnly[i][Symbol.dispose]();
  }
  const end2 = performance.now();
  console.log(`Separate: literal ${(mid - start2).toFixed(2)}ms, class ${(end2 - mid).toFixed(2)}ms`);
}

callSiteTest();

// using 構文のシミュレーション（スコープごとに生成→破棄）
console.log("\n--- using構文シミュレーション（ネスト） ---");

function simulateUsing(createFn, depth = 3) {
  const lock = createFn();
  if (depth > 0) {
    simulateUsing(createFn, depth - 1);
  }
  lock[Symbol.dispose]();
}

function benchUsing(name, createFn) {
  // ウォームアップ
  for (let i = 0; i < 100; i++) {
    simulateUsing(createFn, 3);
  }
  
  const start = performance.now();
  for (let i = 0; i < 10000; i++) {
    simulateUsing(createFn, 3);
  }
  const end = performance.now();
  console.log(`${name} (nested using x10000): ${(end - start).toFixed(2)}ms`);
}

benchUsing("literal", createLockLiteral);
benchUsing("class", () => new LockClass());
