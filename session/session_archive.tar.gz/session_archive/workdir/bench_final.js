// 総浚い検証: 本当に computed property やリテラルが関係あるのか？
// 静的プロパティでも毎回関数を作れば遅くなるはず

console.log("=== 総浚い検証 ===\n");

const SYM = Symbol("dispose");

// ========== リテラル + computed + 毎回新関数 ==========
function literalComputedNewFn() {
  return {
    [SYM]() {}
  };
}

// ========== リテラル + computed + 共有関数 ==========
const sharedFn = function() {};
function literalComputedSharedFn() {
  return {
    [SYM]: sharedFn
  };
}

// ========== リテラル + 静的キー + 毎回新関数 ==========
function literalStaticNewFn() {
  return {
    dispose() {}
  };
}

// ========== リテラル + 静的キー + 共有関数 ==========
function literalStaticSharedFn() {
  return {
    dispose: sharedFn
  };
}

// ========== 後付け + computed + 毎回新関数 ==========
function addLaterComputedNewFn() {
  const obj = {};
  obj[SYM] = function() {};
  return obj;
}

// ========== 後付け + computed + 共有関数 ==========
function addLaterComputedSharedFn() {
  const obj = {};
  obj[SYM] = sharedFn;
  return obj;
}

// ========== 後付け + 静的キー + 毎回新関数 ==========
function addLaterStaticNewFn() {
  const obj = {};
  obj.dispose = function() {};
  return obj;
}

// ========== 後付け + 静的キー + 共有関数 ==========
function addLaterStaticSharedFn() {
  const obj = {};
  obj.dispose = sharedFn;
  return obj;
}

// ========== class ==========
class WithClass {
  [SYM]() {}
}
class WithClassStatic {
  dispose() {}
}

// ベンチマーク: 生成のみ
function benchCreate(name, createFn, iterations = 100000) {
  for (let i = 0; i < 1000; i++) createFn();
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    createFn();
  }
  return performance.now() - start;
}

// ベンチマーク: 生成 + 呼び出し (Symbol キー)
function benchCreateAndCallSym(name, createFn, iterations = 100000) {
  for (let i = 0; i < 1000; i++) {
    const obj = createFn();
    obj[SYM]();
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const obj = createFn();
    obj[SYM]();
  }
  return performance.now() - start;
}

// ベンチマーク: 生成 + 呼び出し (静的キー)
function benchCreateAndCallStatic(name, createFn, iterations = 100000) {
  for (let i = 0; i < 1000; i++) {
    const obj = createFn();
    obj.dispose();
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const obj = createFn();
    obj.dispose();
  }
  return performance.now() - start;
}

console.log("=== 生成コストのみ ===\n");

const results = [];

results.push(["リテラル + computed + 毎回新関数", benchCreate("", literalComputedNewFn)]);
results.push(["リテラル + computed + 共有関数", benchCreate("", literalComputedSharedFn)]);
results.push(["リテラル + 静的キー + 毎回新関数", benchCreate("", literalStaticNewFn)]);
results.push(["リテラル + 静的キー + 共有関数", benchCreate("", literalStaticSharedFn)]);
results.push(["後付け + computed + 毎回新関数", benchCreate("", addLaterComputedNewFn)]);
results.push(["後付け + computed + 共有関数", benchCreate("", addLaterComputedSharedFn)]);
results.push(["後付け + 静的キー + 毎回新関数", benchCreate("", addLaterStaticNewFn)]);
results.push(["後付け + 静的キー + 共有関数", benchCreate("", addLaterStaticSharedFn)]);
results.push(["class + computed", benchCreate("", () => new WithClass())]);
results.push(["class + 静的キー", benchCreate("", () => new WithClassStatic())]);

console.log("パターン                              | 時間");
console.log("--------------------------------------|--------");
for (const [name, time] of results) {
  console.log(`${name.padEnd(38)}| ${time.toFixed(2)}ms`);
}

console.log("\n\n=== 生成 + 呼び出し (computed/Symbol キー) ===\n");

const resultsCall = [];

resultsCall.push(["リテラル + computed + 毎回新関数", benchCreateAndCallSym("", literalComputedNewFn)]);
resultsCall.push(["リテラル + computed + 共有関数", benchCreateAndCallSym("", literalComputedSharedFn)]);
resultsCall.push(["後付け + computed + 毎回新関数", benchCreateAndCallSym("", addLaterComputedNewFn)]);
resultsCall.push(["後付け + computed + 共有関数", benchCreateAndCallSym("", addLaterComputedSharedFn)]);
resultsCall.push(["class + computed", benchCreateAndCallSym("", () => new WithClass())]);

console.log("パターン                              | 時間");
console.log("--------------------------------------|--------");
for (const [name, time] of resultsCall) {
  console.log(`${name.padEnd(38)}| ${time.toFixed(2)}ms`);
}

console.log("\n\n=== 生成 + 呼び出し (静的キー) ===\n");

const resultsCallStatic = [];

resultsCallStatic.push(["リテラル + 静的キー + 毎回新関数", benchCreateAndCallStatic("", literalStaticNewFn)]);
resultsCallStatic.push(["リテラル + 静的キー + 共有関数", benchCreateAndCallStatic("", literalStaticSharedFn)]);
resultsCallStatic.push(["後付け + 静的キー + 毎回新関数", benchCreateAndCallStatic("", addLaterStaticNewFn)]);
resultsCallStatic.push(["後付け + 静的キー + 共有関数", benchCreateAndCallStatic("", addLaterStaticSharedFn)]);
resultsCallStatic.push(["class + 静的キー", benchCreateAndCallStatic("", () => new WithClassStatic())]);

console.log("パターン                              | 時間");
console.log("--------------------------------------|--------");
for (const [name, time] of resultsCallStatic) {
  console.log(`${name.padEnd(38)}| ${time.toFixed(2)}ms`);
}

console.log("\n\n=== まとめ: 各条件の影響 ===\n");

// 条件ごとの比較
console.log("【リテラル vs 後付け】(computed + 毎回新関数 + 呼び出し)");
const litComp = benchCreateAndCallSym("", literalComputedNewFn);
const addComp = benchCreateAndCallSym("", addLaterComputedNewFn);
console.log(`  リテラル: ${litComp.toFixed(2)}ms`);
console.log(`  後付け:   ${addComp.toFixed(2)}ms`);
console.log(`  → ${Math.abs(litComp - addComp) < 5 ? "ほぼ同じ" : (litComp > addComp ? "リテラルが遅い" : "後付けが遅い")}`);

console.log("\n【computed vs 静的キー】(リテラル + 毎回新関数 + 呼び出し)");
const compKey = benchCreateAndCallSym("", literalComputedNewFn);
const staticKey = benchCreateAndCallStatic("", literalStaticNewFn);
console.log(`  computed: ${compKey.toFixed(2)}ms`);
console.log(`  静的キー: ${staticKey.toFixed(2)}ms`);
console.log(`  → ${Math.abs(compKey - staticKey) < 5 ? "ほぼ同じ" : (compKey > staticKey ? "computedが遅い" : "静的キーが遅い")}`);

console.log("\n【毎回新関数 vs 共有関数】(リテラル + computed + 呼び出し)");
const newFn = benchCreateAndCallSym("", literalComputedNewFn);
const sharedFnResult = benchCreateAndCallSym("", literalComputedSharedFn);
console.log(`  毎回新関数: ${newFn.toFixed(2)}ms`);
console.log(`  共有関数:   ${sharedFnResult.toFixed(2)}ms`);
console.log(`  → ${newFn / sharedFnResult > 2 ? `毎回新関数が ${(newFn / sharedFnResult).toFixed(1)}倍遅い！` : "大差なし"}`);

console.log("\n【毎回新関数 vs 共有関数】(リテラル + 静的キー + 呼び出し)");
const newFnStatic = benchCreateAndCallStatic("", literalStaticNewFn);
const sharedFnStatic = benchCreateAndCallStatic("", literalStaticSharedFn);
console.log(`  毎回新関数: ${newFnStatic.toFixed(2)}ms`);
console.log(`  共有関数:   ${sharedFnStatic.toFixed(2)}ms`);
console.log(`  → ${newFnStatic / sharedFnStatic > 2 ? `毎回新関数が ${(newFnStatic / sharedFnStatic).toFixed(1)}倍遅い！` : "大差なし"}`);
