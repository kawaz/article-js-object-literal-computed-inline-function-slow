// プリミティブ値 vs 関数オブジェクト の Deopt 検証
// 毎回異なる値でも、プリミティブなら Deopt は起きないのか？

console.log("=== プリミティブ vs 関数オブジェクト ===\n");

const SYM = Symbol("test");

// --- 関数オブジェクト ---

// パターンA1: computed + 毎回新しい関数
function createWithNewFunction() {
  return { [SYM]: function() {} };
}

// パターンA2: computed + 共有関数
const sharedFn = function() {};
function createWithSharedFunction() {
  return { [SYM]: sharedFn };
}

// --- プリミティブ値 ---

// パターンB1: computed + 毎回新しい数値（ランダム）
let counter = 0;
function createWithNewNumber() {
  return { [SYM]: counter++ };
}

// パターンB2: computed + 固定数値
function createWithFixedNumber() {
  return { [SYM]: 42 };
}

// パターンB3: computed + 毎回新しい文字列
function createWithNewString() {
  return { [SYM]: `str-${counter++}` };
}

// パターンB4: computed + 固定文字列
function createWithFixedString() {
  return { [SYM]: "fixed" };
}

// --- オブジェクト ---

// パターンC1: computed + 毎回新しいオブジェクト
function createWithNewObject() {
  return { [SYM]: { inner: 1 } };
}

// パターンC2: computed + 共有オブジェクト
const sharedObj = { inner: 1 };
function createWithSharedObject() {
  return { [SYM]: sharedObj };
}

// --- 配列 ---

// パターンD1: computed + 毎回新しい配列
function createWithNewArray() {
  return { [SYM]: [1, 2, 3] };
}

// パターンD2: computed + 共有配列
const sharedArr = [1, 2, 3];
function createWithSharedArray() {
  return { [SYM]: sharedArr };
}

// ベンチマーク（生成のみ）
function benchCreate(name, createFn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) createFn();
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    createFn();
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

// ベンチマーク（生成 + プロパティアクセス）
function benchCreateAndAccess(name, createFn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    const obj = createFn();
    const _ = obj[SYM];
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const obj = createFn();
    const _ = obj[SYM];
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

// ベンチマーク（大量オブジェクトへのアクセス）
function benchAccessMany(name, createFn, iterations = 100000) {
  const objects = [];
  for (let i = 0; i < iterations; i++) {
    objects.push(createFn());
  }
  
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    const _ = objects[i][SYM];
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const _ = objects[i][SYM];
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

console.log("--- 生成コスト ---");
console.log("\n[関数]");
benchCreate("新しい関数 (毎回生成)", createWithNewFunction);
benchCreate("共有関数", createWithSharedFunction);

console.log("\n[数値]");
benchCreate("新しい数値 (カウンタ)", createWithNewNumber);
benchCreate("固定数値 (42)", createWithFixedNumber);

console.log("\n[文字列]");
benchCreate("新しい文字列 (毎回生成)", createWithNewString);
benchCreate("固定文字列", createWithFixedString);

console.log("\n[オブジェクト]");
benchCreate("新しいオブジェクト (毎回生成)", createWithNewObject);
benchCreate("共有オブジェクト", createWithSharedObject);

console.log("\n[配列]");
benchCreate("新しい配列 (毎回生成)", createWithNewArray);
benchCreate("共有配列", createWithSharedArray);

console.log("\n\n--- 生成 + アクセス ---");
console.log("\n[関数]");
benchCreateAndAccess("新しい関数 (毎回生成)", createWithNewFunction);
benchCreateAndAccess("共有関数", createWithSharedFunction);

console.log("\n[数値]");
counter = 0;
benchCreateAndAccess("新しい数値 (カウンタ)", createWithNewNumber);
benchCreateAndAccess("固定数値 (42)", createWithFixedNumber);

console.log("\n[オブジェクト]");
benchCreateAndAccess("新しいオブジェクト (毎回生成)", createWithNewObject);
benchCreateAndAccess("共有オブジェクト", createWithSharedObject);

console.log("\n\n--- 大量オブジェクトへのアクセス（IC の影響を見る）---");
console.log("\n[関数]");
benchAccessMany("新しい関数 (毎回生成)", createWithNewFunction);
benchAccessMany("共有関数", createWithSharedFunction);

console.log("\n[数値]");
counter = 0;
benchAccessMany("新しい数値 (カウンタ)", createWithNewNumber);
benchAccessMany("固定数値 (42)", createWithFixedNumber);

console.log("\n[オブジェクト]");
benchAccessMany("新しいオブジェクト (毎回生成)", createWithNewObject);
benchAccessMany("共有オブジェクト", createWithSharedObject);

console.log("\n\n--- Shape 確認 ---");

const fn1 = createWithNewFunction();
const fn2 = createWithNewFunction();
const fnShared1 = createWithSharedFunction();
const fnShared2 = createWithSharedFunction();

console.log("新しい関数: fn1[SYM] === fn2[SYM]?", fn1[SYM] === fn2[SYM]);
console.log("共有関数: fnShared1[SYM] === fnShared2[SYM]?", fnShared1[SYM] === fnShared2[SYM]);

counter = 0;
const num1 = createWithNewNumber();
const num2 = createWithNewNumber();
console.log("新しい数値: num1[SYM] === num2[SYM]?", num1[SYM] === num2[SYM], `(${num1[SYM]} vs ${num2[SYM]})`);

const obj1 = createWithNewObject();
const obj2 = createWithNewObject();
console.log("新しいオブジェクト: obj1[SYM] === obj2[SYM]?", obj1[SYM] === obj2[SYM]);

console.log("\n\n--- 関数呼び出しの Deopt テスト ---");

// 関数呼び出しがある場合の比較
function benchCall(name, createFn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    const obj = createFn();
    obj[SYM]();
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const obj = createFn();
    obj[SYM]();
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
}

benchCall("新しい関数を呼び出し", createWithNewFunction);
benchCall("共有関数を呼び出し", createWithSharedFunction);
