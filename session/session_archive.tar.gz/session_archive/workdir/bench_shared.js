// 関数を共有するパターンの検証
// 毎回新しい関数を作るのではなく、同じ関数オブジェクトを再利用したら速くなるか？

console.log("=== 関数共有パターンの検証 ===\n");

// パターン1: 元のコード（毎回新しい関数）
function createLockOriginal() {
  let released = false;
  return {
    release() {
      if (released) return;
      released = true;
    },
    [Symbol.dispose]() {
      this.release();
    }
  };
}

// パターン2: dispose が release を参照（でも毎回新しい関数）
function createLockDisposeCallsRelease() {
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
  };
  return {
    release,
    [Symbol.dispose]() {
      release();  // this.release() じゃなくて直接
    }
  };
}

// パターン3: dispose と release が同じ関数！
function createLockSharedFunction() {
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
  };
  return {
    release,
    [Symbol.dispose]: release  // ← 同じ関数を使い回す
  };
}

// パターン4: 後付けで同じ関数を設定
function createLockAddLaterShared() {
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
  };
  const obj = { release };
  obj[Symbol.dispose] = release;  // ← 同じ関数
  return obj;
}

// パターン5: モジュールレベルで関数を定義（クロージャなし）
// ※ released の状態管理ができないので、this を使う必要がある
const sharedDispose = function() {
  if (this.released) return;
  this.released = true;
};

function createLockModuleLevelFunction() {
  return {
    released: false,
    release: sharedDispose,
    [Symbol.dispose]: sharedDispose
  };
}

// パターン6: class（比較用）
class LockClass {
  released = false;
  release() {
    if (this.released) return;
    this.released = true;
  }
  [Symbol.dispose]() {
    this.release();
  }
}

// ベンチマーク
function bench(name, createFn, iterations = 100000) {
  // ウォームアップ
  for (let i = 0; i < 1000; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name}: ${(end - start).toFixed(2)}ms`);
  return end - start;
}

console.log("--- 生成 + dispose ---");
bench("1. original (毎回新関数)", createLockOriginal);
bench("2. dispose calls release", createLockDisposeCallsRelease);
bench("3. shared function (release = dispose)", createLockSharedFunction);
bench("4. addLater + shared", createLockAddLaterShared);
bench("5. module-level function", createLockModuleLevelFunction);
bench("6. class", () => new LockClass());

console.log("\n--- 長時間実行 ---");

function runLong(name, createFn) {
  const times = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    times.push(performance.now() - start);
  }
  console.log(`${name}: ${times.map(t => t.toFixed(1)).join(', ')}ms`);
}

runLong("1. original", createLockOriginal);
runLong("3. shared function", createLockSharedFunction);
runLong("5. module-level", createLockModuleLevelFunction);
runLong("6. class", () => new LockClass());

console.log("\n--- 関数の同一性確認 ---");

const orig1 = createLockOriginal();
const orig2 = createLockOriginal();
console.log("original: dispose === dispose?", orig1[Symbol.dispose] === orig2[Symbol.dispose]);

const shared1 = createLockSharedFunction();
const shared2 = createLockSharedFunction();
console.log("shared: dispose === dispose?", shared1[Symbol.dispose] === shared2[Symbol.dispose]);

const module1 = createLockModuleLevelFunction();
const module2 = createLockModuleLevelFunction();
console.log("module-level: dispose === dispose?", module1[Symbol.dispose] === module2[Symbol.dispose]);

const class1 = new LockClass();
const class2 = new LockClass();
console.log("class: dispose === dispose?", class1[Symbol.dispose] === class2[Symbol.dispose]);
