// try-finally vs simple loop の比較検証（using なし版）
// Node.js 22 では using がまだ使えないので

console.log("=== try-finally vs simple loop 比較 ===\n");

// テスト対象のファクトリ
function createLockLiteral() {
  let released = false;
  return {
    release() {
      if (released) return;
      released = true;
    },
    [Symbol.dispose]() {
      this.release();
    }
  };
}

class LockClass {
  released = false;
  release() {
    if (this.released) return;
    this.released = true;
  }
  [Symbol.dispose]() {
    this.release();
  }
}

// パターン1: try-finally で手動 dispose
function benchTryFinally(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    try {
      // 何か処理（ここでは空）
    } finally {
      lock[Symbol.dispose]();
    }
  }
  const end = performance.now();
  console.log(`${name} (try-finally): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン2: 単純なループで dispose
function benchSimpleLoop(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name} (simple loop): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン3: dispose を呼ばない（生成コストのみ）
function benchCreateOnly(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
  }
  const end = performance.now();
  console.log(`${name} (create only): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン4: 生成を分離して dispose のみ計測
function benchDisposeOnly(name, createFn, iterations = 100000) {
  // 先に全部生成
  const locks = [];
  for (let i = 0; i < iterations; i++) {
    locks.push(createFn());
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    locks[i][Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name} (dispose only): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

console.log("--- literal computed ---");
benchCreateOnly("literal", createLockLiteral);
benchDisposeOnly("literal", createLockLiteral);
benchSimpleLoop("literal", createLockLiteral);
benchTryFinally("literal", createLockLiteral);

console.log("\n--- class ---");
benchCreateOnly("class", () => new LockClass());
benchDisposeOnly("class", () => new LockClass());
benchSimpleLoop("class", () => new LockClass());
benchTryFinally("class", () => new LockClass());

console.log("\n\n=== 長時間実行での比較 ===\n");

function runLongComparison(name, createFn) {
  console.log(`--- ${name} ---`);
  
  // try-finally
  const tryFinallyTimes = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      try {
      } finally {
        lock[Symbol.dispose]();
      }
    }
    tryFinallyTimes.push(performance.now() - start);
  }
  console.log(`try-finally: ${tryFinallyTimes.map(t => t.toFixed(1)).join(', ')}ms`);
  
  // simple loop
  const simpleTimes = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    simpleTimes.push(performance.now() - start);
  }
  console.log(`simple loop: ${simpleTimes.map(t => t.toFixed(1)).join(', ')}ms`);
}

runLongComparison("literal computed", createLockLiteral);
console.log();
runLongComparison("class", () => new LockClass());

console.log("\n\n=== try-finally のオーバーヘッド検証 ===\n");

// try-finally 自体のコストを見る（例外なしの場合）
function benchTryFinallyOverhead() {
  let sum = 0;
  
  // try-finally あり
  const start1 = performance.now();
  for (let i = 0; i < 1000000; i++) {
    try {
      sum += i;
    } finally {
      // 空
    }
  }
  const time1 = performance.now() - start1;
  
  // try-finally なし
  const start2 = performance.now();
  for (let i = 0; i < 1000000; i++) {
    sum += i;
  }
  const time2 = performance.now() - start2;
  
  console.log(`try-finally (empty): ${time1.toFixed(2)}ms`);
  console.log(`no try-finally:      ${time2.toFixed(2)}ms`);
  console.log(`overhead:            ${(time1 - time2).toFixed(2)}ms`);
}

benchTryFinallyOverhead();

console.log("\n\n=== Deopt トリガーの検証 ===\n");

// 同じ呼び出しサイトで異なるターゲットを呼ぶと Deopt が起きるか
function benchCallTargetVariation() {
  const locks = [];
  
  // 100000個のリテラルオブジェクト（それぞれ別の関数）
  for (let i = 0; i < 100000; i++) {
    locks.push(createLockLiteral());
  }
  
  // 最初の1000回
  let start = performance.now();
  for (let i = 0; i < 1000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`first 1k:  ${(performance.now() - start).toFixed(2)}ms`);
  
  // 次の1000回
  start = performance.now();
  for (let i = 1000; i < 2000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`2nd 1k:    ${(performance.now() - start).toFixed(2)}ms`);
  
  // 残り全部
  start = performance.now();
  for (let i = 2000; i < 100000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`rest 98k:  ${(performance.now() - start).toFixed(2)}ms`);
}

console.log("literal (dispose 100k objects with different functions):");
benchCallTargetVariation();

function benchClassCallTarget() {
  const locks = [];
  
  // 100000個のクラスインスタンス（全て同じ関数を共有）
  for (let i = 0; i < 100000; i++) {
    locks.push(new LockClass());
  }
  
  // 最初の1000回
  let start = performance.now();
  for (let i = 0; i < 1000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`first 1k:  ${(performance.now() - start).toFixed(2)}ms`);
  
  // 次の1000回
  start = performance.now();
  for (let i = 1000; i < 2000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`2nd 1k:    ${(performance.now() - start).toFixed(2)}ms`);
  
  // 残り全部
  start = performance.now();
  for (let i = 2000; i < 100000; i++) {
    locks[i][Symbol.dispose]();
  }
  console.log(`rest 98k:  ${(performance.now() - start).toFixed(2)}ms`);
}

console.log("\nclass (dispose 100k objects with same function):");
benchClassCallTarget();
