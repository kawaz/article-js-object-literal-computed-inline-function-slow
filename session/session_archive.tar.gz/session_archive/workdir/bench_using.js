// using vs try-finally の比較検証
// using 構文自体が遅いのか、パターンの問題なのかを切り分ける

console.log("=== using vs try-finally 比較 ===\n");

// テスト対象のファクトリ
function createLockLiteral() {
  let released = false;
  return {
    release() {
      if (released) return;
      released = true;
    },
    [Symbol.dispose]() {
      this.release();
    }
  };
}

class LockClass {
  released = false;
  release() {
    if (this.released) return;
    this.released = true;
  }
  [Symbol.dispose]() {
    this.release();
  }
}

// パターン1: using 構文
function benchUsing(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    using lock = createFn();
    // 何か処理（ここでは空）
  }
  const end = performance.now();
  console.log(`${name} (using): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン2: try-finally で手動 dispose
function benchTryFinally(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    try {
      // 何か処理（ここでは空）
    } finally {
      lock[Symbol.dispose]();
    }
  }
  const end = performance.now();
  console.log(`${name} (try-finally): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン3: 単純なループで dispose
function benchSimpleLoop(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
    lock[Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name} (simple loop): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン4: dispose を呼ばない（生成コストのみ）
function benchCreateOnly(name, createFn, iterations = 100000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    const lock = createFn();
  }
  const end = performance.now();
  console.log(`${name} (create only): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

// パターン5: 生成を分離して dispose のみ計測
function benchDisposeOnly(name, createFn, iterations = 100000) {
  // 先に全部生成
  const locks = [];
  for (let i = 0; i < iterations; i++) {
    locks.push(createFn());
  }
  
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    locks[i][Symbol.dispose]();
  }
  const end = performance.now();
  console.log(`${name} (dispose only): ${(end - start).toFixed(2)}ms`);
  return end - start;
}

console.log("--- literal computed ---");
benchCreateOnly("literal", createLockLiteral);
benchDisposeOnly("literal", createLockLiteral);
benchSimpleLoop("literal", createLockLiteral);
benchTryFinally("literal", createLockLiteral);
benchUsing("literal", createLockLiteral);

console.log("\n--- class ---");
benchCreateOnly("class", () => new LockClass());
benchDisposeOnly("class", () => new LockClass());
benchSimpleLoop("class", () => new LockClass());
benchTryFinally("class", () => new LockClass());
benchUsing("class", () => new LockClass());

console.log("\n\n=== 長時間実行での比較 ===\n");

function runLongComparison(name, createFn) {
  console.log(`--- ${name} ---`);
  
  // using
  const usingTimes = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      using lock = createFn();
    }
    usingTimes.push(performance.now() - start);
  }
  console.log(`using:       ${usingTimes.map(t => t.toFixed(1)).join(', ')}ms`);
  
  // try-finally
  const tryFinallyTimes = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      try {
      } finally {
        lock[Symbol.dispose]();
      }
    }
    tryFinallyTimes.push(performance.now() - start);
  }
  console.log(`try-finally: ${tryFinallyTimes.map(t => t.toFixed(1)).join(', ')}ms`);
  
  // simple loop
  const simpleTimes = [];
  for (let batch = 0; batch < 5; batch++) {
    const start = performance.now();
    for (let i = 0; i < 100000; i++) {
      const lock = createFn();
      lock[Symbol.dispose]();
    }
    simpleTimes.push(performance.now() - start);
  }
  console.log(`simple loop: ${simpleTimes.map(t => t.toFixed(1)).join(', ')}ms`);
}

runLongComparison("literal computed", createLockLiteral);
console.log();
runLongComparison("class", () => new LockClass());

console.log("\n\n=== 呼び出しサイトの分離テスト ===\n");

// 同じ呼び出しサイトで両方呼ぶ vs 別々の呼び出しサイト

function mixedCallSite(createFnA, createFnB, iterations = 50000) {
  const start = performance.now();
  for (let i = 0; i < iterations; i++) {
    // 同じループ内で両方
    const lockA = createFnA();
    lockA[Symbol.dispose]();
    const lockB = createFnB();
    lockB[Symbol.dispose]();
  }
  return performance.now() - start;
}

function separateCallSite(createFnA, createFnB, iterations = 50000) {
  const start = performance.now();
  // 別々のループ
  for (let i = 0; i < iterations; i++) {
    const lockA = createFnA();
    lockA[Symbol.dispose]();
  }
  for (let i = 0; i < iterations; i++) {
    const lockB = createFnB();
    lockB[Symbol.dispose]();
  }
  return performance.now() - start;
}

console.log("literal + class を混ぜた場合:");
console.log(`  mixed call site:    ${mixedCallSite(createLockLiteral, () => new LockClass()).toFixed(2)}ms`);
console.log(`  separate call site: ${separateCallSite(createLockLiteral, () => new LockClass()).toFixed(2)}ms`);
